/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
LOAD DATA LOCAL INFILE 'allthethings.libgenrs_updated.00000.dat.gz' INTO TABLE `libgenrs_updated` CHARACTER SET binary FIELDS TERMINATED BY ',' ENCLOSED BY '"' ESCAPED BY '\\' LINES STARTING BY '' TERMINATED BY '\n' IGNORE 1 LINES (`ID`,`Title`,`VolumeInfo`,`Series`,`Periodical`,`Author`,`Year`,`Edition`,`Publisher`,`City`,`Pages`,`PagesInFile`,`Language`,`Topic`,`Library`,`Issue`,`Identifier`,`ISSN`,`ASIN`,`UDC`,`LBC`,`DDC`,`LCC`,`Doi`,`Googlebookid`,`OpenLibraryID`,`Commentary`,`DPI`,`Color`,`Cleaned`,`Orientation`,`Paginated`,`Scanned`,`Bookmarked`,`Searchable`,`Filesize`,`Extension`,`MD5`,`Generic`,`Visible`,`Locator`,`Local`,`TimeAdded`,`TimeLastModified`,`Coverurl`,`Tags`,`IdentifierWODash`);
